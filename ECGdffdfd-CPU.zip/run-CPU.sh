#!/bin/bash
cpp -P CPU/src/Platform.fdl | fdlsim $1