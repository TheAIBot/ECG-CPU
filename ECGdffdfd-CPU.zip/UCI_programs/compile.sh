#!/bin/bash

java -jar UCIC.jar "$@"