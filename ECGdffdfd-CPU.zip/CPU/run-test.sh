#!/bin/bash
cpp -P $1 | fdlsim $2